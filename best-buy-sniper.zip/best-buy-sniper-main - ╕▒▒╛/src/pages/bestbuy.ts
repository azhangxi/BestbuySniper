import { getBrowser } from '@driver/index';
import { Browser, BrowserContext, Page } from 'playwright';
import {find, get, random} from 'lodash';
import { CustomerInformation, getCustomerInformation, getPaymentInformation, PaymentInformation } from '@core/configs';
import { logger } from '@core/logger';
import { resolve } from 'path';
import { sendMessage as sendDiscordMessage } from '@core/notifications/discord';
import { existsSync, writeFileSync } from 'fs';

interface ProductInformation {
  searchText?: string;
  sku: string;
  model: string;
  productName: string;
  productPage: string;
}

export const wait = (ms: number) => {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
};

const bestBuyUrl = 'https://www.bestbuy.ca/en-ca';
const skuSelector = '#root > div > div.x-page-content.container_3Sp8P > div.x-product-detail-page > div.modelDetailSection_1Ou2j > div.modelInformationContainer_3hV4x > div:nth-child(2) > span';
const addToCartSel = 'div.col-sm-6_1okfB:nth-child(2) > .productActionWrapperNonMobile_10B89 > .x-checkout-experience-new > .addToCartButtonContainer_3_s4w > .addToCartContainer_20u-G > form > button:not([disabled])';

export class BestBuy {
  private browser: Browser;

  private readonly products: ProductInformation[];

  private page?: Page;

  private context?: BrowserContext;



  constructor({ products }: { products: any[] }) {
    this.browser = getBrowser();
    this.products = products;
  }

  async open(): Promise<Page> {
    this.context = await this.browser.newContext({
      permissions: [],
    });
    this.page = await this.context.newPage();

    return this.page;
  }

  async close(): Promise<void> {  
    await this.page?.close();
    await this.context?.close();

    this.page = undefined;
    this.context = undefined;
  }

  public async purchaseProduct() {
    for (const product of this.products) {
      try {
        await this.goToProductPage(product);
        await this.validateProductMatch(product);
        await this.addToCart(product);
        await this.checkout();
        await this.continueAsGuest();
        await this.submitGuestOrder();
        await Promise.all([
          sendDiscordMessage({ message: `ORDER COMPLETE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! OH YEAH`}),
        ]);
        return true;
      } catch (error) {
        logger.error(error);
        if (error.message === 'Browser is considered a bot, aborting attempt') {
          throw error;
        }
      }
    }
    return false;
  }

  private async goToProductPage(product: ProductInformation): Promise<void> {
    const { productPage } = product;
    const { sku: expectedSKU } = product;
    const url = `${bestBuyUrl}${productPage}`;
    const page = await this.getPage();
    // await page.goto(bestBuyUrl, {timeout: 10000});
    // const searchField = '#root > div > div.pageContentContainer_3J5wd > header > div > div > div.headerContent_3f5qJ.upperToolbar_2zx5x > div.toolbar_uptjx > div.search_2cOWm.tabletDesktop_2pYUA > div > div > form > div > input';
    // await page.waitForSelector(searchField, {timeout: 5000});
    // await page.click(searchField);
    // await page.focus(searchField);
    // await page.type(searchField, expectedSKU);
    // await page.press(searchField, "Enter");
    // const clickUrl = '#root > div > div.x-page-content.container_3Sp8P > div.singleColumn_BCnZ4.singleColumn > div > main > div:nth-child(1) > div.productsContainer_2xEUC > div.productListingContainer_1Iyio > div.productList_31W-E > ul > div > div > div > a > div > div > div.col-xs-8_1v0z0.col-sm-12_G_a2r.productItemTextContainer_HocvR > div.productItemName_3IZ3c';
    //
    // try {
    //   await page.waitForSelector(clickUrl, {timeout: 2000});
    // } catch (error) {
    //   throw error;
    // }
    // await page.click(clickUrl);

    await page.goto(url);
    logger.info(`Navigating to ${bestBuyUrl}${productPage}`);
    // await wait(2000);

    if (await page.waitForSelector(skuSelector, {timeout: 180000}) === null) {

        // throw new Error('Browser is considered a bot, aborting attempt');
    }
    // logger.info(`Test Message`);

    logger.info(`Navigation completed`);
  }

  private async validateProductMatch(product: ProductInformation) {
    const { sku: expectedSKU } = product;
    const page = await this.getPage();

    logger.info(`Validating that page corresponds to sku ${expectedSKU}`);

    const skuValue = await page.$eval(skuSelector, (element) => element.textContent);

    if (expectedSKU !== skuValue!.trim())
      throw new Error(`Product page does not belong to product with sku ${expectedSKU}`);

    logger.info(`Page corresponds to sku ${expectedSKU}`);
  }

  public async addToCart(product: ProductInformation) {
    const { productName } = product;
    logger.info(`Checking stock of product "${productName}"`);

    if (!(await this.isInStock())) {
        throw new Error('Product not in stock, aborting attempt');
    } else {
      logger.info(`"${productName}" in stock, sending discord msg...`);
      const page = await this.getPage();
      await page.click(addToCartSel);
      const result = await this.hasItemBeenAddedToCart();
      if (!result) throw new Error(`Product "${productName}" was not able to be added to the cart`);
      logger.info(`sending discord msg!`);
      await Promise.all([
        sendDiscordMessage({ message: `Product "${productName}" in stock!`}),
      ]);
      // for (let i = 0; i < 100; i++) {
      //   await Promise.all([
      //     sendDiscordMessage({ message: `Product "${productName}" in stock!`}),
      //   ]);
      //   await wait(700);
      // }
    }

    // const productInStockScreenshotPath = resolve(`screenshots/${Date.now()}_product-in-stock.png`);

    // await page.screenshot({
    //   path: productInStockScreenshotPath,
    //   type: 'png'
    // });

    // await page.screenshot({
    //   path: productAddedImagePath,
    //   type: 'png'
    // });

    // await Promise.all([
    //   sendDiscordMessage({ message: `Product "${productName}" added to cart!`, image: productAddedImagePath }),
    // ]);
  }

  public async isInStock() {
    const page = await this.getPage();
    const buttonEnabled = await page.$(addToCartSel);
    if (buttonEnabled) {
      return true;
    } else {
      return false;
    }
  }

  private async hasItemBeenAddedToCart() {

    const page = await this.getPage();
    const completedSuccessfuly = await page.waitForSelector('#root > div > div.x-page-content.container_3Sp8P > div.pageContainer_29XJJ > div > h1', {timeout: 180000});

  //   const completedSuccessfuly = await page.waitForResponse(
  //       (response: any) => response.url() === 'https://www.bestbuy.ca/en-ca/required-parts/10424797' && response.status() === 200
  //   );

    return completedSuccessfuly;
  }

  private async checkout(retrying: boolean = false) {
    const page = await this.getPage();
    const customerInformation = getCustomerInformation();

    logger.info(`Navigating to cart`);

    await page.goto('https://www.bestbuy.ca/en-ca/basket');

    if (retrying && (await this.isCartEmpty())) throw new Error('Cart is empty, aborting attempt');
    await this.changeZipCode(customerInformation.zipcode);

    // const startingCheckoutScreenshotPath = resolve(`screenshots/${Date.now()}_starting-checkout.png`);

    // await page.screenshot({
    //   path: startingCheckoutScreenshotPath,
    //   type: 'png'
    // });
    //
    // await Promise.all([
    //   sendDiscordMessage({ message: `Attempting checkout`, image: startingCheckoutScreenshotPath }),
    // ]);

    // await this.clickCheckoutButton();

    try {
      await page.waitForSelector('#root > div > div.other-context-sign-in-page-content-container > div > div > div > div._30PCW.mmkfI._1OJZg._3tHkf > div > div.guest-continue-link-wrapper > a', {timeout: 180000});

      logger.info('Checkout successful, starting order placement');
    } catch (error) {
      logger.warn(error);
      logger.info('Refreshing and trying to checkout again');

      // await Promise.all([
      //    sendDiscordMessage({ message: `Checkout did not went through, trying again`, image: startingCheckoutScreenshotPath }),
      // ]);

      await this.checkout(true);
    }
  }

  private async isCartEmpty() {
    const page = await this.getPage();

    const element = await page.$('#root > div > div.x-page-content.container_3Sp8P > div.loader_1jBrE > div.loadedContent_e3Dc0 > section > section > div.content_bK_Rp > div');
    // Wait for me to complete bot check
    await wait(30000);
    const elementTextContent = await element?.textContent();

    return elementTextContent ? elementTextContent.trim().toLowerCase().startsWith('Looks like it\'s empty!') : false;
  }

  private async changeZipCode(zipCode: string) {
    const page = await this.getPage();

    logger.info('Waiting for zip code change button to become available');

    await page.waitForSelector('#postalCode');

    logger.info('Changing zip code...');

    await page.click('#postalCode');
    await page.focus('#postalCode');
    for (let i = 0; i < 6; i++) {
      await page.press('#postalCode', 'Backspace');
    }
    await page.type('#postalCode', zipCode);
    await page.click('#root > div > div.pageContent_1vNlW > div.loader_3thnw > div > section > div > main > section > section.enterPcSection_3r_Cf > div > form > div > button');
    logger.info('Trying to checkout...');
    await page.click('#root > div > div.pageContent_1vNlW > div.loader_3thnw > div > section > div > main > section > section.cost-sum-section_3pPEp > div:nth-child(3) > div > a');


    // await page.waitForFunction(
    //   (zipCode: string) => {
    //     const element = document.querySelector('#postalCode');
    //
    //     if (!!element) {
    //       const { textContent } = element;
    //
    //       return textContent?.trim() === zipCode;
    //     }
    //   },
    //   zipCode,
    //   { polling: 200 }
    // );
  }

  // private async clickCheckoutButton() {
  //   const page = await this.getPage();
  //
  //   logger.info('Trying to checkout...');
  //
  //   await page.click('#root > div > div.x-page-content.container_3Sp8P > div.loader_1jBrE > div.loadedContent_e3Dc0 > section > div > section > section.cost-sum-section_2v3QX > div:nth-child(3) > div > a:not(disabled)');
  // }

  private async continueAsGuest() {
    const page = await this.getPage();
    await page.waitForSelector('#root > div > div.other-context-sign-in-page-content-container > div > div > div > div.VyTnq._1tm4U.h8UpA._24uQr > div > div.guest-continue-link-wrapper > a');
    logger.info('Continuing as guest');

    await page.click('#root > div > div.other-context-sign-in-page-content-container > div > div > div > div.VyTnq._1tm4U.h8UpA._24uQr > div > div.guest-continue-link-wrapper > a');

    await page.waitForSelector('#email');
  }

  private async submitGuestOrder() {
    const page = await this.getPage();
    const customerInformation = getCustomerInformation();
    const paymentInformation = getPaymentInformation();

    logger.info('Started order information completion');

    await this.completeShippingInformation(customerInformation);
    await this.completeContactInformation(customerInformation);

    // await page.screenshot({
    //   path: resolve(`screenshots/${Date.now()}_first-information-page-completed.png`),
    //   type: 'png',
    //   fullPage: true
    // });

    logger.info('Continuing to payment screen...');

    await page.click('#posElement > section > section.cost-sum-section > button');

    await this.completePaymentInformation(paymentInformation);

    // await page.screenshot({
    //   path: resolve(`screenshots/${Date.now()}_second-information-page-completed.png`),
    //   type: 'png',
    //   fullPage: true
    // });

    await page.click('#posElement > section > section.cost-sum-section > button');
    logger.info('Performing last validation before placing order...');

    let a = await page.waitForSelector('#root > div.loader_1jBrE > div.loadedContent_e3Dc0 > div > div > div > section.template-body > main > section > header > h2');
    if (!a) {
      await this.submitGuestOrder();
    }
    const totalContainer = await page.$('#posElement > section > section.cost-sum-section > div > div > div.loadedContent_e3Dc0 > table > tfoot > tr > td');
    const totalContainerTextContent = await totalContainer?.textContent();
    const parsedTotal = totalContainerTextContent ? parseFloat(totalContainerTextContent.replace('$', '')) : 0;

    if (parsedTotal === 0 || parsedTotal > customerInformation.budget)
      throw new Error('Total amount does not seems right, aborting');

    logger.info('Placing order...');

    // const placingOrderScreenshotPath = resolve(`screenshots/${Date.now()}_placing-order.png`);

    // await page.screenshot({
    //   path: placingOrderScreenshotPath,
    //   type: 'png',
    //   fullPage: true
    // });

    // await Promise.all([
    //   sendDiscordMessage({ message: `Placing order...`, image: placingOrderScreenshotPath }),
    // ]);

    if (existsSync('purchase.json')) {
      logger.warn('Purchase already completed, ending process');

      process.exit(2);
    }

    // *** UNCOMMENT THIS SECTION TO ENABLE AUTO-CHECKOUT ***
    const placeOrderButton = await page.$('#posElement > section > section.cost-sum-section > button');

    if (!!placeOrderButton) {
      await page.click('#posElement > section > section.cost-sum-section > button');
    }

    await wait(3000);

    logger.info('Order placed!');

    if (!existsSync('purchase.json')) writeFileSync('purchase.json', '{}');

    // const orderPlacedScreenshotPath = resolve(`screenshots/${Date.now()}_order-placed-1.png`);
    //
    // await page.screenshot({
    //   path: orderPlacedScreenshotPath,
    //   type: 'png',
    //   fullPage: true
    // });
    //
    // await Promise.all([
    //   sendDiscordMessage({ message: `Order placed!`, image: orderPlacedScreenshotPath }),
    // ]);

    await wait(3000);

    await page.screenshot({
      path: resolve(`screenshots/${Date.now()}_order-placed-2.png`),
      type: 'png',
      fullPage: true
    });

    await wait(14000);
  }

  private async completeShippingInformation(customerInformation: CustomerInformation) {
    const page = await this.getPage();

    logger.info('Filling shipping information...');

    await page.type('[id="firstName"]', customerInformation.firstName);
    await page.type('[id="lastName"]', customerInformation.lastName);

    const hideSuggestionsButton = await page.$('.address-form__cell .autocomplete__toggle');
    const hideSuggestionsButtonTextContent = await hideSuggestionsButton?.textContent();

    if (hideSuggestionsButtonTextContent?.trim().toLocaleLowerCase() === 'hide suggestions')
      await page.click('.address-form__cell .autocomplete__toggle');

    await page.type('[id="addressLine"]', customerInformation.address);

    // if (customerInformation.addressSecondLine) {
    //   await page.click('.address-form__showAddress2Link');
    //   await page.type('[id="consolidatedAddresses.ui_address_2.street2"]', customerInformation.addressSecondLine);
    // }

    await page.type('[id="city"]', customerInformation.city);
    await page.selectOption('[id="country"]', customerInformation.state);
    await page.type('[id="postalCode"]', customerInformation.zipcode);


    logger.info('Shipping information completed');
  }

  private async completeContactInformation(customerInformation: CustomerInformation) {
    const page = await this.getPage();

    logger.info('Filling contact information...');

    await page.type('[id="email"]', customerInformation.email);
    await page.type('[id="phone"]', customerInformation.phone);
    // await page.check('#text-updates');

    logger.info('Contact information completed');
  }

  private async completePaymentInformation(paymentInformation: PaymentInformation) {
    const page = await this.getPage();

    logger.info('Filling payment information...');

    await page.waitForSelector('#paymentForm > div > div > div > div:nth-child(2) > div.creditCardSelector > fieldset > div > div.createNew.creatNewSelected');
    await page.type('#shownCardNumber', paymentInformation.creditCardNumber);
    await page.selectOption('[id="expirationMonth"]', paymentInformation.expirationMonth);
    logger.info('exp date: ' + paymentInformation.expirationMonth + ':' + paymentInformation.expirationYear);
    await page.selectOption('[id="expirationYear"]', paymentInformation.expirationYear);
    await page.type('[id="cvv"]', paymentInformation.cvv);
    // await page.type('[id="payment.billingAddress.firstName"]', paymentInformation.firstName);
    // await page.type('[id="payment.billingAddress.lastName"]', paymentInformation.lastName);
    // await page.type('[id="payment.billingAddress.street"]', paymentInformation.address);
    // await page.type('[id="payment.billingAddress.city"]', paymentInformation.city);
    // await page.type('[id="payment.billingAddress.state"]', paymentInformation.state);
    // await page.type('[id="payment.billingAddress.zipcode"]', paymentInformation.zipcode);

    logger.info('Payment information completed');
  }

  private async getPage() {
    return this.page!;
  }
}
